### Hexlet tests and linter status:
[![Actions Status](https://github.com/soratnik32/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/soratnik32/python-project-49/actions)
<a href="https://codeclimate.com/github/soratnik32/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c3b843c31f825f75f27d/maintainability" /></a>
